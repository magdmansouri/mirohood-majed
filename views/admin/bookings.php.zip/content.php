<?php
// views/admin/content.php - مدیریت محتوا
$contentModel = new SiteContent();
$contents = $contentModel->getAll();
$csrf_token = generate_csrf_token();

$sections = [
    'home' => [
        'title' => '🏠 صفحه اصلی',
        'fields' => [
            'home.eyebrow' => 'خط بالای هیرو',
            'home.title_line1' => 'عنوان هیرو — خط اول',
            'home.title_line2' => 'عنوان هیرو — خط دوم (طلایی)',
            'home.subtitle' => 'زیرنویس هیرو',
            'home.cta_button' => 'متن دکمه (رزرو)',
            'home.packages_eyebrow' => 'عنوان بخش پکیج‌ها',
            'home.packages_title' => 'تیتر اصلی پکیج‌ها',
            'home.gallery_title' => 'عنوان بخش گالری',
        ],
    ],
    'booking' => [
        'title' => '📅 صفحه رزرو',
        'fields' => [
            'booking.title' => 'عنوان صفحه رزرو',
            'booking.subtitle' => 'زیرنویس صفحه رزرو',
            'booking.form_name' => 'برچسب نام و نام خانوادگی',
            'booking.form_phone' => 'برچسب شماره موبایل',
            'booking.form_package' => 'برچسب انتخاب پکیج',
            'booking.form_date' => 'برچسب انتخاب تاریخ',
            'booking.form_time' => 'برچسب انتخاب ساعت',
            'booking.form_note' => 'برچسب توضیح اضافه',
            'booking.form_submit' => 'متن دکمه ارسال',
            'booking.success_message' => 'پیام موفقیت',
        ],
    ],
];
?>
<h1 class="admin-page-title">مدیریت محتوا</h1>
<p class="admin-page-subtitle">هر کدام را عوض کنی و «ذخیره» را بزنی، همان لحظه روی سایت اعمال می‌شود.</p>

<div class="admin-card">
    <form method="POST" action="/admin/api/update-content" id="content-form">
        <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
        
        <?php foreach ($sections as $sectionKey => $section): ?>
            <div style="border-bottom:1px solid rgba(200,168,98,0.04);padding:1.25rem 0;">
                <h3 style="font-family:'Cormorant Garamond',Georgia,serif;font-size:1.15rem;font-weight:300;color:var(--color-champagne);margin-bottom:1rem;">
                    <?php echo $section['title']; ?>
                </h3>
                
                <?php foreach ($section['fields'] as $key => $label): ?>
                    <div style="margin-bottom:0.8rem;display:flex;gap:0.6rem;align-items:flex-end;flex-wrap:wrap;">
                        <div style="flex:1;min-width:200px;">
                            <label class="admin-label"><?php echo $label; ?></label>
                            <input type="text" name="content[<?php echo $key; ?>]" value="<?php echo htmlspecialchars($contents[$key] ?? ''); ?>" class="admin-input" style="font-size:0.9rem;">
                        </div>
                        <button type="button" onclick="saveContent('<?php echo $key; ?>')" class="admin-btn" style="padding:0.5rem 1.2rem;font-size:0.7rem;white-space:nowrap;">
                            <i class="fas fa-save"></i> ذخیره
                        </button>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endforeach; ?>
        
        <button type="button" onclick="saveAllContent()" class="admin-btn" style="margin-top:1.5rem;">
            <i class="fas fa-save"></i> ذخیره همه
        </button>
    </form>
</div>

<script>
function saveContent(key) {
    var input = document.querySelector('input[name="content[' + key + ']"]');
    if (!input) {
        showToast('❌ خطا: فیلد پیدا نشد', 'error');
        return;
    }
    
    var fd = new FormData();
    fd.append('key', key);
    fd.append('value', input.value);
    fd.append('csrf_token', '<?php echo $csrf_token; ?>');
    
    fetch('/admin/api/update-content', {
        method: 'POST',
        body: fd,
        headers: {
            'X-Requested-With': 'XMLHttpRequest'
        }
    })
    .then(function(response) {
        if (!response.ok) {
            throw new Error('Server error: ' + response.status);
        }
        return response.json();
    })
    .then(function(data) {
        if (data.success) {
            showToast('✅ ' + data.message, 'success');
        } else {
            showToast('❌ ' + (data.message || 'خطا در ذخیره'), 'error');
        }
    })
    .catch(function(error) {
        console.error('Error:', error);
        showToast('❌ خطا در ارتباط با سرور: ' + error.message, 'error');
    });
}

function saveAllContent() {
    var form = document.getElementById('content-form');
    var fd = new FormData(form);
    
    fetch('/admin/api/update-content', {
        method: 'POST',
        body: fd,
        headers: {
            'X-Requested-With': 'XMLHttpRequest'
        }
    })
    .then(function(response) {
        if (!response.ok) {
            throw new Error('Server error: ' + response.status);
        }
        return response.json();
    })
    .then(function(data) {
        if (data.success) {
            showToast('✅ ' + data.message, 'success');
        } else {
            showToast('❌ ' + (data.message || 'خطا در ذخیره'), 'error');
        }
    })
    .catch(function(error) {
        console.error('Error:', error);
        showToast('❌ خطا در ارتباط با سرور: ' + error.message, 'error');
    });
}
</script>