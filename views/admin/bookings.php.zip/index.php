<?php
// views/admin/index.php - داشبورد
$stats = $stats ?? [];
$recent_bookings = $recent_bookings ?? [];
?>
<div style="display:flex;justify-content:space-between;align-items:flex-start;flex-wrap:wrap;gap:1rem;margin-bottom:2rem;">
    <div>
        <h1 class="admin-page-title">داشبورد</h1>
        <p class="admin-page-subtitle" style="margin-bottom:0;">نمای کلی از وضعیت استودیو</p>
    </div>
    <div style="display:flex;gap:0.5rem;">
        <span style="font-size:0.7rem;color:#8a8580;background:rgba(255,255,255,0.03);padding:0.3rem 1rem;border-radius:9999px;border:1px solid rgba(200,168,98,0.06);">
            <i class="fas fa-sync-alt" style="margin-left:0.3rem;font-size:0.6rem;"></i>
            <?php echo date('Y/m/d H:i'); ?>
        </span>
    </div>
</div>

<!-- ===== Quick Links ===== -->
<div class="quick-links">
    <a href="<?php echo url('admin/bookings'); ?>" class="quick-link-card">
        <i class="fas fa-calendar-check"></i>
        <p>رزروها</p>
    </a>
    <a href="<?php echo url('admin/gallery'); ?>" class="quick-link-card">
        <i class="fas fa-images"></i>
        <p>گالری</p>
    </a>
    <a href="<?php echo url('admin/content'); ?>" class="quick-link-card">
        <i class="fas fa-pen-to-square"></i>
        <p>محتوا</p>
    </a>
    <a href="<?php echo url('admin/media'); ?>" class="quick-link-card">
        <i class="fas fa-film"></i>
        <p>رسانه</p>
    </a>
    <a href="<?php echo url('admin/hours'); ?>" class="quick-link-card">
        <i class="fas fa-clock"></i>
        <p>ساعت کاری</p>
    </a>
</div>

<!-- ===== Stats ===== -->
<div class="admin-stat-grid">
    <div class="admin-stat-card">
        <div class="icon-bg"><i class="fas fa-calendar-check"></i></div>
        <p class="num" style="color:var(--color-champagne);"><?php echo $stats['total_bookings'] ?? 0; ?></p>
        <p class="label">کل رزروها</p>
    </div>
    <div class="admin-stat-card">
        <div class="icon-bg"><i class="fas fa-hourglass-half"></i></div>
        <p class="num" style="color:var(--warning);"><?php echo $stats['pending_bookings'] ?? 0; ?></p>
        <p class="label">در انتظار</p>
    </div>
    <div class="admin-stat-card">
        <div class="icon-bg"><i class="fas fa-check-circle"></i></div>
        <p class="num" style="color:var(--success);"><?php echo $stats['confirmed_bookings'] ?? 0; ?></p>
        <p class="label">تایید شده</p>
    </div>
    <div class="admin-stat-card">
        <div class="icon-bg"><i class="fas fa-times-circle"></i></div>
        <p class="num" style="color:var(--danger);"><?php echo $stats['cancelled_bookings'] ?? 0; ?></p>
        <p class="label">لغو شده</p>
    </div>
    <div class="admin-stat-card">
        <div class="icon-bg"><i class="fas fa-images"></i></div>
        <p class="num" style="color:var(--info);"><?php echo $stats['total_gallery'] ?? 0; ?></p>
        <p class="label">تصاویر گالری</p>
    </div>
</div>

<!-- ===== Recent Bookings ===== -->
<div class="admin-card">
    <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:0.5rem;margin-bottom:1rem;">
        <h2 class="admin-card-title" style="margin-bottom:0;">آخرین رزروها</h2>
        <a href="<?php echo url('admin/bookings'); ?>" style="color:var(--color-muted);font-size:0.8rem;transition:color 0.3s ease;">
            مشاهده همه <i class="fas fa-arrow-left" style="font-size:0.6rem;margin-right:0.3rem;"></i>
        </a>
    </div>
    
    <?php if (!empty($recent_bookings)): ?>
        <div class="admin-table-wrap">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>نام</th>
                        <th>پکیج</th>
                        <th>تاریخ</th>
                        <th>وضعیت</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($recent_bookings as $booking): ?>
                        <tr>
                            <td><?php echo h($booking['full_name']); ?></td>
                            <td style="color:var(--color-muted);font-size:0.8rem;"><?php echo h($booking['package_id']); ?></td>
                            <td style="color:var(--color-muted);font-size:0.8rem;"><?php echo h($booking['jalali_date']); ?></td>
                            <td>
                                <span class="admin-badge <?php echo strtolower($booking['status']); ?>">
                                    <?php 
                                        $statusMap = [
                                            'PENDING' => 'در انتظار',
                                            'CONFIRMED' => 'تایید شده',
                                            'CANCELLED' => 'لغو شده',
                                            'COMPLETED' => 'انجام شده'
                                        ];
                                        echo $statusMap[$booking['status']] ?? $booking['status'];
                                    ?>
                                </span>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php else: ?>
        <p style="color:var(--color-muted);text-align:center;padding:2rem 0;">هیچ رزروی وجود ندارد.</p>
    <?php endif; ?>
</div>