<?php
// views/admin/gallery.php - مدیریت گالری
$images = $images ?? [];
$csrf_token = generate_csrf_token();
?>
<h1 class="admin-page-title">مدیریت گالری</h1>
<p class="admin-page-subtitle">آپلود و مدیریت تصاویر گالری</p>

<!-- ===== Upload Form ===== -->
<div class="admin-card">
    <h2 class="admin-card-title">آپلود تصویر جدید</h2>
    <form method="POST" enctype="multipart/form-data" action="/admin/api/upload-gallery" id="gallery-upload-form">
        <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
        
        <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:1rem;margin-top:0.5rem;">
            <div>
                <label class="admin-label">تصویر</label>
                <input type="file" name="image" accept="image/*" required class="admin-input" style="padding:0.5rem;">
            </div>
            <div>
                <label class="admin-label">توضیح (Alt)</label>
                <input type="text" name="alt" placeholder="توضیح تصویر" class="admin-input">
            </div>
            <div>
                <label class="admin-label">دسته‌بندی</label>
                <input type="text" name="category" placeholder="portrait, brand, ..." class="admin-input">
            </div>
        </div>
        
        <button type="submit" class="admin-btn" style="margin-top:1.25rem;">
            <i class="fas fa-upload"></i> آپلود تصویر
        </button>
    </form>
</div>

<!-- ===== Gallery Grid ===== -->
<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:1rem;">
    <?php if (!empty($images)): ?>
        <?php foreach ($images as $image): ?>
            <div class="gallery-item">
                <img src="<?php echo h($image['src']); ?>" alt="<?php echo h($image['alt']); ?>">
                <div class="overlay">
                    <span><?php echo h($image['category']); ?></span>
                    <button onclick="deleteImage(<?php echo $image['id']; ?>)" title="حذف تصویر">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            </div>
        <?php endforeach; ?>
    <?php else: ?>
        <p style="color:var(--color-muted);text-align:center;padding:3rem 0;grid-column:1/-1;">هیچ تصویری در گالری وجود ندارد.</p>
    <?php endif; ?>
</div>

<script>
function deleteImage(id) {
    if (!confirm('آیا از حذف این تصویر مطمئن هستید؟')) return;
    
    var fd = new FormData();
    fd.append('image_id', id);
    fd.append('csrf_token', '<?php echo $csrf_token; ?>');
    
    fetch('/admin/api/delete-gallery', {
        method: 'POST',
        body: fd,
        headers: {
            'X-Requested-With': 'XMLHttpRequest'
        }
    })
    .then(function(response) { 
        if (!response.ok) {
            throw new Error('Server error: ' + response.status);
        }
        return response.json(); 
    })
    .then(function(data) {
        if (data.success) {
            showToast('✅ تصویر با موفقیت حذف شد', 'success');
            location.reload();
        } else {
            showToast('❌ ' + (data.message || 'خطا در حذف'), 'error');
        }
    })
    .catch(function(error) {
        console.error('Delete error:', error);
        showToast('❌ خطا در ارتباط با سرور: ' + error.message, 'error');
    });
}

// ===== نمایش پیام‌های آپلود =====
document.getElementById('gallery-upload-form').addEventListener('submit', function(e) {
    var submitBtn = this.querySelector('.admin-btn');
    submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> در حال آپلود...';
    submitBtn.disabled = true;
});
</script>