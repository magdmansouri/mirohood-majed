<?php
// views/admin/bookings.php - مدیریت رزروها
$bookings = $bookings ?? [];
$status_filter = $status_filter ?? null;
$total_bookings = $total_bookings ?? 0;
$csrf_token = generate_csrf_token();

$filters = [
    null => 'همه',
    'PENDING' => 'در انتظار',
    'CONFIRMED' => 'تایید شده',
    'CANCELLED' => 'لغو شده',
    'COMPLETED' => 'انجام شده'
];

$statusMap = [
    'PENDING' => ['label' => 'در انتظار', 'class' => 'pending'],
    'CONFIRMED' => ['label' => 'تایید شده', 'class' => 'confirmed'],
    'CANCELLED' => ['label' => 'لغو شده', 'class' => 'cancelled'],
    'COMPLETED' => ['label' => 'انجام شده', 'class' => 'completed']
];
?>
<h1 class="admin-page-title">مدیریت رزروها</h1>
<p class="admin-page-subtitle">تعداد کل: <?php echo (int)$total_bookings; ?></p>

<input type="hidden" id="csrf_token_bookings" value="<?php echo h($csrf_token); ?>">

<!-- ===== Filters ===== -->
<div style="display:flex;flex-wrap:wrap;gap:0.4rem;margin-bottom:1.5rem;">
    <?php foreach ($filters as $value => $label): ?>
        <a href="<?php echo url('admin/bookings'.($value ? '?status='.$value : '')); ?>" class="filter-pill <?php echo $status_filter === $value ? 'active' : ''; ?>">
            <?php echo $label; ?>
        </a>
    <?php endforeach; ?>
</div>

<!-- ===== Table ===== -->
<div class="admin-card">
    <div class="admin-table-wrap">
        <table class="admin-table">
            <thead>
                <tr>
                    <th>نام</th>
                    <th>موبایل</th>
                    <th>پکیج</th>
                    <th>تاریخ</th>
                    <th>ساعت</th>
                    <th>وضعیت</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($bookings)): ?>
                    <?php foreach ($bookings as $booking): ?>
                        <tr>
                            <td><?php echo h($booking['full_name']); ?></td>
                            <td style="color:var(--color-muted);font-size:0.85rem;"><?php echo h($booking['phone']); ?></td>
                            <td style="color:var(--color-muted);font-size:0.85rem;"><?php echo h($booking['package_id']); ?></td>
                            <td style="color:var(--color-muted);font-size:0.85rem;"><?php echo h($booking['jalali_date']); ?></td>
                            <td style="color:var(--color-muted);font-size:0.85rem;"><?php echo h($booking['time']); ?></td>
                            <td>
                                <select class="status-select" data-id="<?php echo h($booking['id']); ?>" style="background:rgba(255,255,255,0.03);border:1px solid rgba(200,168,98,0.08);border-radius:0.5rem;padding:0.3rem 0.6rem;color:var(--color-ivory);font-size:0.75rem;cursor:pointer;font-family:'Vazirmatn',sans-serif;">
                                    <?php foreach ($statusMap as $value => $meta): ?>
                                        <option value="<?php echo $value; ?>" <?php echo $booking['status'] === $value ? 'selected' : ''; ?>>
                                            <?php echo $meta['label']; ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="6" style="text-align:center;padding:2rem 0;color:var(--color-muted);">
                            هیچ رزروی ثبت نشده است.
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    var csrfToken = document.getElementById('csrf_token_bookings').value;
    
    document.querySelectorAll('.status-select').forEach(function(select) {
        select.dataset.previousValue = select.value;
        
        select.addEventListener('change', function() {
            var id = this.dataset.id;
            var status = this.value;
            var oldStatus = this.dataset.previousValue;
            
            if (!id) return;
            
            var fd = new FormData();
            fd.append('booking_id', id);
            fd.append('status', status);
            fd.append('csrf_token', csrfToken);
            
            this.disabled = true;
            
            fetch('<?php echo url("admin/api/update-booking-status"); ?>', {
                method: 'POST',
                headers: {
                    'X-Requested-With': 'XMLHttpRequest',
                    'Accept': 'application/json'
                },
                body: fd
            })
            .then(function(response) {
                if (!response.ok) throw new Error('Server Error');
                return response.json();
            })
            .then(function(data) {
                if (data.success) {
                    select.dataset.previousValue = status;
                    showToast(data.message || '✅ وضعیت با موفقیت تغییر کرد', 'success');
                } else {
                    select.value = oldStatus;
                    showToast(data.message || '❌ خطا در ذخیره وضعیت', 'error');
                }
            })
            .catch(function() {
                select.value = oldStatus;
                showToast('❌ ارتباط با سرور برقرار نشد', 'error');
            })
            .finally(function() {
                select.disabled = false;
            });
        });
    });
});
</script>