<?php
// views/admin/layout.php - قالب ادمین
set_security_headers();
if (session_status() === PHP_SESSION_NONE) session_start();
if (!isset($page_title)) $page_title = SITE_NAME;
$content = $content ?? '';
$current_page = $current_page ?? '';

$navItems = [
    ['key' => 'admin', 'url' => 'admin', 'icon' => 'fa-chart-pie', 'label' => 'داشبورد'],
    ['key' => 'admin-bookings', 'url' => 'admin/bookings', 'icon' => 'fa-calendar-check', 'label' => 'رزروها'],
    ['key' => 'admin-gallery', 'url' => 'admin/gallery', 'icon' => 'fa-images', 'label' => 'گالری'],
    ['key' => 'admin-content', 'url' => 'admin/content', 'icon' => 'fa-pen-to-square', 'label' => 'محتوا'],
    ['key' => 'admin-media', 'url' => 'admin/media', 'icon' => 'fa-film', 'label' => 'رسانه'],
    ['key' => 'admin-hours', 'url' => 'admin/hours', 'icon' => 'fa-clock', 'label' => 'ساعت کاری']
];
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo h($page_title); ?> | پنل ادمین Lowfuzion</title>
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@100..900&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    
    <style>
        /* ============================================================
           ROOT VARIABLES
           ============================================================ */
        :root {
            --color-noir: #0a0908;
            --color-ivory: #f4f1ea;
            --color-champagne: #c8a862;
            --color-champagne-dim: #a8893a;
            --color-muted: #8a8580;
            --color-panel: #12100e;
            --color-card: #1a1715;
            --color-glass-border: rgba(200,168,98,0.08);
            --sidebar-w: 260px;
            --success: #4ade80;
            --warning: #fbbf24;
            --danger: #f87171;
            --info: #60a5fa;
        }
        
        /* ============================================================
           RESET
           ============================================================ */
        * { margin:0; padding:0; box-sizing:border-box; }
        body {
            background: var(--color-noir);
            color: var(--color-ivory);
            font-family: 'Vazirmatn', sans-serif;
            min-height: 100vh;
        }
        a { color: inherit; text-decoration: none; }
        
        /* ============================================================
           SIDEBAR
           ============================================================ */
        .admin-sidebar {
            position: fixed;
            top: 0;
            right: 0;
            bottom: 0;
            width: var(--sidebar-w);
            background: var(--color-panel);
            border-left: 1px solid var(--color-glass-border);
            display: flex;
            flex-direction: column;
            z-index: 100;
            transition: transform 0.3s ease;
        }
        .admin-sidebar .logo-box {
            padding: 1.5rem 1.2rem;
            border-bottom: 1px solid var(--color-glass-border);
        }
        .admin-sidebar .logo-box .logo {
            font-family: 'Cormorant Garamond', Georgia, serif;
            font-size: 1.6rem;
            font-weight: 300;
            color: var(--color-ivory);
        }
        .admin-sidebar .logo-box .logo span { color: var(--color-champagne); }
        .admin-sidebar .logo-box .tag {
            font-size: 0.55rem;
            letter-spacing: 0.2em;
            color: var(--color-muted);
            text-transform: uppercase;
            margin-top: 0.1rem;
        }
        
        .admin-nav {
            flex: 1;
            padding: 0.8rem 0.6rem;
            display: flex;
            flex-direction: column;
            gap: 0.2rem;
            overflow-y: auto;
        }
        .admin-nav a {
            display: flex;
            align-items: center;
            gap: 0.8rem;
            padding: 0.7rem 1rem;
            border-radius: 0.6rem;
            color: var(--color-muted);
            font-size: 0.85rem;
            font-weight: 400;
            transition: all 0.25s ease;
            position: relative;
        }
        .admin-nav a i {
            width: 18px;
            text-align: center;
            font-size: 0.9rem;
        }
        .admin-nav a:hover {
            background: rgba(255,255,255,0.03);
            color: var(--color-ivory);
        }
        .admin-nav a.active {
            background: linear-gradient(90deg, rgba(200,168,98,0.12), rgba(200,168,98,0.02));
            color: var(--color-champagne);
        }
        .admin-nav a.active::before {
            content: '';
            position: absolute;
            right: 0;
            top: 15%;
            bottom: 15%;
            width: 3px;
            border-radius: 0 3px 3px 0;
            background: var(--color-champagne);
        }
        
        .admin-sidebar .bottom-box {
            padding: 0.8rem 0.6rem 1.2rem;
            border-top: 1px solid var(--color-glass-border);
        }
        .admin-sidebar .bottom-box a {
            display: flex;
            align-items: center;
            gap: 0.8rem;
            padding: 0.7rem 1rem;
            border-radius: 0.6rem;
            color: var(--color-muted);
            font-size: 0.82rem;
            transition: all 0.25s ease;
        }
        .admin-sidebar .bottom-box a:hover {
            color: var(--danger);
            background: rgba(239,68,68,0.06);
        }
        .admin-sidebar .bottom-box a.view-site:hover {
            color: var(--color-champagne);
            background: rgba(200,168,98,0.06);
        }
        
        /* ============================================================
           TOPBAR (Mobile)
           ============================================================ */
        .admin-topbar {
            display: none;
            position: sticky;
            top: 0;
            z-index: 90;
            background: rgba(10,9,8,0.95);
            backdrop-filter: blur(16px);
            border-bottom: 1px solid var(--color-glass-border);
            padding: 0.8rem 1rem;
            align-items: center;
            justify-content: space-between;
        }
        .admin-topbar .logo {
            font-family: 'Cormorant Garamond', Georgia, serif;
            font-size: 1.3rem;
            font-weight: 300;
        }
        .admin-topbar .logo span { color: var(--color-champagne); }
        .admin-topbar button {
            background: none;
            border: 1px solid var(--color-glass-border);
            border-radius: 0.5rem;
            color: var(--color-ivory);
            font-size: 1rem;
            padding: 0.4rem 0.7rem;
            cursor: pointer;
        }
        .sidebar-overlay {
            display: none;
            position: fixed;
            inset: 0;
            background: rgba(0,0,0,0.6);
            z-index: 99;
        }
        
        /* ============================================================
           MAIN CONTENT
           ============================================================ */
        .admin-main {
            margin-right: var(--sidebar-w);
            min-height: 100vh;
            padding: 2rem 2.5rem 4rem;
        }
        
        /* ============================================================
           RESPONSIVE
           ============================================================ */
        @media (max-width: 900px) {
            .admin-sidebar { transform: translateX(100%); }
            .admin-sidebar.open { transform: translateX(0); box-shadow: -20px 0 60px rgba(0,0,0,0.5); }
            .admin-topbar { display: flex; }
            .sidebar-overlay.open { display: block; }
            .admin-main { margin-right: 0; padding: 1.5rem 1rem 3rem; }
        }
        
        /* ============================================================
           COMMON COMPONENTS
           ============================================================ */
        .admin-page-title {
            font-family: 'Cormorant Garamond', Georgia, serif;
            font-size: 2.2rem;
            font-weight: 300;
            color: var(--color-ivory);
            margin-bottom: 0.2rem;
        }
        .admin-page-subtitle {
            color: var(--color-muted);
            font-size: 0.85rem;
            margin-bottom: 2rem;
        }
        
        .admin-card {
            background: var(--color-card);
            border: 1px solid var(--color-glass-border);
            border-radius: 1rem;
            padding: 1.5rem;
            margin-bottom: 1.5rem;
        }
        .admin-card-title {
            font-family: 'Cormorant Garamond', Georgia, serif;
            font-size: 1.3rem;
            font-weight: 300;
            color: var(--color-ivory);
            margin-bottom: 0.5rem;
        }
        
        .admin-btn {
            display: inline-flex;
            align-items: center;
            gap: 0.4rem;
            padding: 0.6rem 1.6rem;
            background: linear-gradient(135deg, var(--color-champagne), var(--color-champagne-dim));
            border: none;
            border-radius: 9999px;
            color: var(--color-noir);
            font-family: 'Vazirmatn', sans-serif;
            font-size: 0.8rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.25s ease;
        }
        .admin-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 20px rgba(200,168,98,0.2);
        }
        .admin-btn:disabled { opacity: 0.6; cursor: not-allowed; transform: none; }
        
        .admin-btn-outline {
            background: transparent;
            border: 1px solid var(--color-glass-border);
            color: var(--color-ivory);
        }
        .admin-btn-outline:hover {
            border-color: var(--color-champagne);
            color: var(--color-champagne);
            background: rgba(200,168,98,0.04);
        }
        
        .admin-input, .admin-select, .admin-textarea {
            width: 100%;
            padding: 0.6rem 1rem;
            background: rgba(255,255,255,0.03);
            border: 1px solid var(--color-glass-border);
            border-radius: 0.6rem;
            color: var(--color-ivory);
            font-size: 0.88rem;
            font-family: 'Vazirmatn', sans-serif;
            transition: all 0.25s ease;
        }
        .admin-input:focus, .admin-select:focus, .admin-textarea:focus {
            outline: none;
            border-color: var(--color-champagne);
            box-shadow: 0 0 0 3px rgba(200,168,98,0.06);
        }
        .admin-label {
            display: block;
            font-size: 0.75rem;
            color: var(--color-muted);
            margin-bottom: 0.3rem;
        }
        
        /* ===== Stats Grid ===== */
        .admin-stat-grid {
            display: grid;
            grid-template-columns: repeat(5, 1fr);
            gap: 1rem;
            margin-bottom: 2rem;
        }
        @media (max-width: 1100px) { .admin-stat-grid { grid-template-columns: repeat(3, 1fr); } }
        @media (max-width: 640px) { .admin-stat-grid { grid-template-columns: repeat(2, 1fr); } }
        
        .admin-stat-card {
            background: var(--color-card);
            border: 1px solid var(--color-glass-border);
            border-radius: 1rem;
            padding: 1.2rem 1rem;
            text-align: center;
            transition: all 0.3s ease;
        }
        .admin-stat-card:hover {
            border-color: rgba(200,168,98,0.15);
            transform: translateY(-3px);
        }
        .admin-stat-card .num {
            font-family: 'Cormorant Garamond', Georgia, serif;
            font-size: 2.2rem;
            font-weight: 300;
        }
        .admin-stat-card .label {
            font-size: 0.65rem;
            color: var(--color-muted);
            margin-top: 0.1rem;
            letter-spacing: 0.05em;
        }
        .admin-stat-card .icon-bg {
            font-size: 1.8rem;
            opacity: 0.06;
            position: absolute;
            top: 0.5rem;
            left: 0.5rem;
        }
        .admin-stat-card { position: relative; overflow: hidden; }
        
        /* ===== Quick Links ===== */
        .quick-links {
            display: grid;
            grid-template-columns: repeat(5, 1fr);
            gap: 1rem;
            margin-bottom: 2rem;
        }
        @media (max-width: 1100px) { .quick-links { grid-template-columns: repeat(3, 1fr); } }
        @media (max-width: 640px) { .quick-links { grid-template-columns: repeat(2, 1fr); } }
        
        .quick-link-card {
            background: var(--color-card);
            border: 1px solid var(--color-glass-border);
            border-radius: 1rem;
            padding: 1.2rem 1rem;
            text-align: center;
            transition: all 0.3s ease;
        }
        .quick-link-card:hover {
            border-color: var(--color-champagne);
            transform: translateY(-3px);
        }
        .quick-link-card i {
            font-size: 1.5rem;
            color: var(--color-champagne);
        }
        .quick-link-card p {
            font-size: 0.8rem;
            margin-top: 0.3rem;
            color: var(--color-ivory);
        }
        
        /* ===== Table ===== */
        .admin-table-wrap { overflow-x: auto; }
        .admin-table {
            width: 100%;
            border-collapse: collapse;
            font-size: 0.85rem;
            min-width: 600px;
        }
        .admin-table th {
            text-align: right;
            padding: 0.7rem 0.6rem;
            color: var(--color-muted);
            font-weight: 400;
            font-size: 0.7rem;
            border-bottom: 1px solid var(--color-glass-border);
            letter-spacing: 0.05em;
        }
        .admin-table td {
            padding: 0.7rem 0.6rem;
            border-bottom: 1px solid rgba(200,168,98,0.03);
        }
        
        /* ===== Badges ===== */
        .admin-badge {
            display: inline-block;
            padding: 0.2rem 0.8rem;
            border-radius: 9999px;
            font-size: 0.65rem;
            font-weight: 600;
        }
        .admin-badge.pending { background: rgba(234,179,8,0.15); color: var(--warning); }
        .admin-badge.confirmed { background: rgba(34,197,94,0.15); color: var(--success); }
        .admin-badge.cancelled { background: rgba(239,68,68,0.15); color: var(--danger); }
        .admin-badge.completed { background: rgba(59,130,246,0.15); color: var(--info); }
        
        /* ===== Filters ===== */
        .filter-pill {
            display: inline-block;
            padding: 0.3rem 1.2rem;
            border-radius: 9999px;
            border: 1px solid var(--color-glass-border);
            color: var(--color-muted);
            font-size: 0.75rem;
            transition: all 0.2s ease;
            cursor: pointer;
        }
        .filter-pill.active {
            border-color: var(--color-champagne);
            color: var(--color-champagne);
            background: rgba(200,168,98,0.04);
        }
        .filter-pill:hover {
            border-color: var(--color-champagne);
            color: var(--color-ivory);
        }
        
        /* ===== Gallery Item ===== */
        .gallery-item {
            position: relative;
            border-radius: 0.8rem;
            overflow: hidden;
            aspect-ratio: 3/4;
            background: var(--color-panel);
            border: 1px solid var(--color-glass-border);
        }
        .gallery-item img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        .gallery-item .overlay {
            position: absolute;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(10,9,8,0.85);
            backdrop-filter: blur(6px);
            padding: 0.5rem 0.8rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .gallery-item .overlay span { font-size: 0.65rem; color: var(--color-muted); }
        .gallery-item .overlay button {
            background: none;
            border: none;
            color: var(--danger);
            font-size: 0.9rem;
            cursor: pointer;
            transition: all 0.2s ease;
        }
        .gallery-item .overlay button:hover { color: #ff4444; transform: scale(1.1); }
        
        /* ===== Toast ===== */
        .admin-toast-wrap {
            position: fixed;
            bottom: 1.5rem;
            left: 50%;
            transform: translateX(-50%);
            z-index: 9999;
        }
        #toast-message {
            background: var(--color-panel);
            color: var(--color-ivory);
            border: 1px solid var(--color-glass-border);
            border-radius: 0.75rem;
            padding: 0.7rem 1.5rem;
            box-shadow: 0 10px 40px rgba(0,0,0,0.5);
            max-width: 24rem;
            text-align: center;
            font-size: 0.85rem;
        }
        .hidden { display: none !important; }
    </style>
</head>
<body>

    <!-- ===== Topbar (Mobile) ===== -->
    <div class="admin-topbar">
        <span class="logo">Low<span>fuzion</span></span>
        <button id="sidebarToggle"><i class="fas fa-bars"></i></button>
    </div>
    <div class="sidebar-overlay" id="sidebarOverlay"></div>

    <!-- ===== Sidebar ===== -->
    <aside class="admin-sidebar" id="adminSidebar">
        <div class="logo-box">
            <div class="logo">Low<span>fuzion</span></div>
            <div class="tag">Admin Panel</div>
        </div>
        <nav class="admin-nav">
            <?php foreach ($navItems as $item): ?>
                <a href="<?php echo url($item['url']); ?>" class="<?php echo $current_page === $item['key'] ? 'active' : ''; ?>">
                    <i class="fas <?php echo $item['icon']; ?>"></i>
                    <span><?php echo $item['label']; ?></span>
                </a>
            <?php endforeach; ?>
        </nav>
        <div class="bottom-box">
            <a href="<?php echo url(''); ?>" class="view-site" target="_blank">
                <i class="fas fa-arrow-up-left-from-circle"></i>
                <span>مشاهده سایت</span>
            </a>
            <a href="<?php echo url('admin/logout'); ?>">
                <i class="fas fa-right-from-bracket"></i>
                <span>خروج</span>
            </a>
        </div>
    </aside>

    <!-- ===== Main Content ===== -->
    <main class="admin-main">
        <?php echo $content; ?>
    </main>

    <!-- ===== Toast ===== -->
    <div id="toaster" class="admin-toast-wrap hidden">
        <div id="toast-message"></div>
    </div>

    <script>
    document.addEventListener('DOMContentLoaded', function() {
        // ===== Sidebar Toggle =====
        var sidebar = document.getElementById('adminSidebar');
        var overlay = document.getElementById('sidebarOverlay');
        var toggle = document.getElementById('sidebarToggle');
        
        function closeSidebar() {
            sidebar.classList.remove('open');
            overlay.classList.remove('open');
        }
        
        if (toggle) {
            toggle.addEventListener('click', function() {
                sidebar.classList.toggle('open');
                overlay.classList.toggle('open');
            });
        }
        if (overlay) {
            overlay.addEventListener('click', closeSidebar);
        }
        
        // ===== Toast =====
        var toaster = document.getElementById('toaster');
        var toastMsg = document.getElementById('toast-message');
        var toastTimeout = null;
        
        window.showToast = function(message, type) {
            if (!toaster || !toastMsg) return;
            
            var borderColor = 'rgba(200,168,98,0.3)';
            var bg = '#1a1715';
            if (type === 'success') {
                borderColor = '#22c55e';
                bg = 'rgba(22,163,74,0.9)';
            } else if (type === 'error') {
                borderColor = '#ef4444';
                bg = 'rgba(220,38,38,0.9)';
            }
            
            toastMsg.textContent = message;
            toastMsg.style.borderColor = borderColor;
            toastMsg.style.backgroundColor = bg;
            toaster.classList.remove('hidden');
            
            if (toastTimeout) clearTimeout(toastTimeout);
            toastTimeout = setTimeout(function() {
                toaster.classList.add('hidden');
            }, 4000);
        };
    });
    </script>
</body>
</html>