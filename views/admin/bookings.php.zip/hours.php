<?php
// views/admin/hours.php - ساعت کاری
$contentModel = new SiteContent();
$holidayDates = $contentModel->get('holiday_dates');
$holidayDates = $holidayDates ? json_decode($holidayDates, true) : [];
$csrf_token = generate_csrf_token();
?>
<h1 class="admin-page-title">تعطیلی روزهای خاص</h1>
<p class="admin-page-subtitle">روزهایی که دفتر تعطیل است را مشخص کنید</p>

<!-- ===== Add Holiday ===== -->
<div class="admin-card">
    <h2 class="admin-card-title">➕ افزودن روز تعطیل</h2>
    <form method="POST" action="<?php echo url('admin/api/update-exceptions'); ?>" id="holiday-form">
        <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
        
        <div style="display:flex;gap:1rem;align-items:flex-end;flex-wrap:wrap;">
            <div style="flex:1;min-width:200px;">
                <label class="admin-label">تاریخ (مثال: 1404/01/15)</label>
                <input type="text" name="new_holiday" placeholder="1404/01/15" class="admin-input">
            </div>
            <button type="submit" class="admin-btn">
                <i class="fas fa-plus"></i> افزودن
            </button>
        </div>
    </form>
</div>

<!-- ===== Holiday List ===== -->
<div class="admin-card">
    <h2 class="admin-card-title">📋 لیست روزهای تعطیل</h2>
    
    <?php if (!empty($holidayDates)): ?>
        <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:0.5rem;">
            <?php foreach ($holidayDates as $date): ?>
                <div style="display:flex;justify-content:space-between;align-items:center;padding:0.4rem 0.8rem;background:rgba(239,68,68,0.04);border:1px solid rgba(239,68,68,0.06);border-radius:0.5rem;">
                    <span style="color:var(--danger);font-size:0.85rem;">📅 <?php echo htmlspecialchars($date); ?></span>
                    <button onclick="removeHoliday('<?php echo addslashes($date); ?>')" style="background:none;border:none;color:var(--danger);font-size:1rem;cursor:pointer;transition:all 0.2s ease;">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <p style="color:var(--color-muted);text-align:center;padding:1rem 0;">هیچ روز تعطیلی ثبت نشده است.</p>
    <?php endif; ?>
</div>

<script>
function removeHoliday(date) {
    if (!confirm('آیا از حذف این تاریخ مطمئن هستید؟')) return;
    
    var fd = new FormData();
    fd.append('remove', date);
    fd.append('csrf_token', '<?php echo $csrf_token; ?>');
    
    fetch('<?php echo url("admin/api/update-exceptions"); ?>', {
        method: 'POST',
        body: fd
    })
    .then(function(response) { return response.json(); })
    .then(function(data) {
        if (data.success) {
            showToast('✅ روز تعطیل حذف شد', 'success');
            location.reload();
        } else {
            showToast('❌ ' + (data.message || 'خطا در حذف'), 'error');
        }
    })
    .catch(function() {
        showToast('❌ خطا در ارتباط با سرور', 'error');
    });
}
</script>